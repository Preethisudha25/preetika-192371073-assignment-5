# CSA09 – AWT and Swing Assignment (50 Marks)

## Contents
- `Report/Assignment_Report.md` – diagnoses, event table, component trees, pseudocode, traces, comparisons and test plans.
- `Task1_FeePayment/` – separated AWT GUI and service layer.
- `Task3_LibrarySearch/` – resizable Swing library search layout.
- `Task4_DrawPad/` – corrected persistent drawing pad and compile-error experiment.
- `Task5_CurrencyConverter/` – four event-handling styles and completed lambda version.
- `Task6_EventRegistration/` – layered Swing + JDBC registration application, SQL schema and paginated loading.
- `evidence/` – place your own screenshots here.

## Requirements
- JDK 17 or later (JDK 8+ should work for most examples).
- VS Code with Java extensions or another Java IDE.
- MySQL Server for Task 6.
- MySQL Connector/J JAR for Task 6 runtime.

## Compile and run (Windows PowerShell)
Open a terminal in the relevant task folder.

```powershell
javac *.java
java FeePaymentApp
```
Use the class name in each task's README where different. For Task 6, add the MySQL Connector/J JAR to the classpath:
```powershell
javac -cp ".;lib/*" *.java
java -cp ".;lib/*" EventRegistrationApp
```
Edit `DB.java` with your local database name, username and password before running Task 6. Do not commit real passwords to a public GitHub repository; use environment variables or a local ignored config file.

## Evidence you must capture yourself
Screenshots are intentionally not fabricated. Run each program and save genuine screenshots under `evidence/`, with filenames and captions tied to test IDs in the report:
- T3: small, medium and large window sizes.
- T4: before and after minimizing/restoring, showing retained dots and count.
- T5: successful conversion and invalid input dialog; also test Enter.
- T6: valid registration, invalid input, duplicate registration, filtering and export.
- T1/T2: screenshots of the working GUI interactions if your instructor requires them.

## GitHub submission
Create a new GitHub repository, copy this project folder into it, then run:
```powershell
git init
git add .
git commit -m "Add AWT Swing assignment"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the URL with your repository URL. Verify the uploaded files and add the final repository link to your report.
