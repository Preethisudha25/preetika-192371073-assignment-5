import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LibrarySearchScreen extends JFrame {
    private final JTextField query = new JTextField(22);
    private final JComboBox<String> category = new JComboBox<>(new String[]{"All", "Title", "Author", "Subject"});
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Book ID", "Title", "Author", "Category"}, 0);
    private final JTable table = new JTable(model);
    private final JLabel status = new JLabel("Ready.");

    public LibrarySearchScreen() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8, 8));

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchRow.add(new JLabel("Search:"));
        searchRow.add(query);
        searchRow.add(category);
        JButton search = new JButton("Search");
        searchRow.add(search);
        add(searchRow, BorderLayout.NORTH);

        model.addRow(new Object[]{"B101", "Java Programming", "Herbert Schildt", "Computer Science"});
        model.addRow(new Object[]{"B102", "Database System Concepts", "Silberschatz", "Computer Science"});
        model.addRow(new Object[]{"B103", "Clean Code", "Robert C. Martin", "Software"});
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout());
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton prev = new JButton("Prev"), next = new JButton("Next"), reserve = new JButton("Reserve");
        nav.add(prev); nav.add(next); nav.add(reserve);
        south.add(nav, BorderLayout.CENTER);
        south.add(status, BorderLayout.SOUTH);
        add(south, BorderLayout.SOUTH);

        search.addActionListener(e -> {
            String q = query.getText().trim().toLowerCase();
            status.setText(q.isEmpty() ? "Showing all sample books." : "Search completed for: " + q);
        });
        prev.addActionListener(e -> status.setText("Previous page selected."));
        next.addActionListener(e -> status.setText("Next page selected."));
        reserve.addActionListener(e -> status.setText(table.getSelectedRow() < 0 ? "Select a book first." : "Reservation request recorded."));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(460, 300));
        setSize(800, 550);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearchScreen().setVisible(true));
    }
}
