import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ConverterFrameListener extends JFrame implements ActionListener {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JButton button = new JButton("Convert");
    public ConverterFrameListener() {
        super("Converter - Frame Listener");
        setLayout(new FlowLayout());
        add(new JLabel("INR")); add(amount); add(target); add(button);
        button.addActionListener(this); amount.addActionListener(this);
        addWindowListener(new WindowAdapter() { @Override public void windowClosing(WindowEvent e) { dispose(); }});
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); pack();
    }
    @Override public void actionPerformed(ActionEvent e) { convert(); }
    private void convert() {
        try {
            double v = Double.parseDouble(amount.getText().trim());
            if (!Double.isFinite(v) || v < 0) throw new NumberFormatException();
            double rate = "USD".equals(target.getSelectedItem()) ? 0.012 : 0.011;
            JOptionPane.showMessageDialog(this, String.format("%.2f %s", v * rate, target.getSelectedItem()));
        } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Invalid amount"); }
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new ConverterFrameListener().setVisible(true)); }
}
