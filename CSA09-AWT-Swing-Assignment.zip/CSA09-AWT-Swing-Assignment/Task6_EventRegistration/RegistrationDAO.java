import java.sql.*;
import java.util.*;

public class RegistrationDAO {
    public Map<Integer, String> getEvents() throws SQLException {
        Map<Integer, String> events = new LinkedHashMap<>();
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT event_id,event_name FROM events ORDER BY event_name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) events.put(rs.getInt(1), rs.getString(2));
        }
        return events;
    }

    public void insert(String studentId, String studentName, int eventId) throws SQLException {
        String sql = "INSERT INTO registrations(student_id,student_name,event_id) VALUES(?,?,?)";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId); ps.setString(2, studentName); ps.setInt(3, eventId);
            ps.executeUpdate();
        }
    }

    public List<Registration> findPage(Integer eventId, int limit, int offset) throws SQLException {
        String sql = "SELECT r.registration_id,r.student_id,r.student_name,e.event_name,r.registered_at " +
                "FROM registrations r JOIN events e ON r.event_id=e.event_id " +
                (eventId == null ? "" : "WHERE r.event_id=? ") +
                "ORDER BY r.registration_id LIMIT ? OFFSET ?";
        List<Registration> rows = new ArrayList<>();
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            if (eventId != null) ps.setInt(i++, eventId);
            ps.setInt(i++, limit); ps.setInt(i, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new Registration(rs.getLong(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), rs.getString(5)));
            }
        }
        return rows;
    }
}
