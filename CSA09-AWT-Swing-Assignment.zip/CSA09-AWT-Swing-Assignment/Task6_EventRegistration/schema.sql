CREATE DATABASE IF NOT EXISTS campus_events;
USE campus_events;

CREATE TABLE IF NOT EXISTS events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(120) NOT NULL,
    event_date DATE NULL
);

CREATE TABLE IF NOT EXISTS registrations (
    registration_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(30) NOT NULL,
    student_name VARCHAR(120) NOT NULL,
    event_id INT NOT NULL,
    registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_registration_event FOREIGN KEY (event_id) REFERENCES events(event_id),
    CONSTRAINT uq_student_event UNIQUE (student_id, event_id),
    INDEX idx_event_registration (event_id, registration_id)
);

INSERT INTO events(event_name, event_date)
SELECT 'Cultural Fest', '2026-12-10'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE event_name='Cultural Fest');
INSERT INTO events(event_name, event_date)
SELECT 'Tech Symposium', '2026-12-15'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE event_name='Tech Symposium');
INSERT INTO events(event_name, event_date)
SELECT 'Music Night', '2026-12-20'
WHERE NOT EXISTS (SELECT 1 FROM events WHERE event_name='Music Night');
