1. Run `schema.sql` in MySQL Workbench.
2. Add MySQL Connector/J to a `lib` folder inside this task folder.
3. Set environment variables in PowerShell, for example:
   `$env:CAMPUS_DB_URL="jdbc:mysql://localhost:3306/campus_events"`
   `$env:CAMPUS_DB_USER="root"`
   `$env:CAMPUS_DB_PASSWORD="your-local-password"`
4. Compile: `javac -cp ".;lib/*" *.java`
5. Run: `java -cp ".;lib/*" EventRegistrationApp`
6. Use Registration menu to enter registrations and Committee menu to filter, page and export.
The unique database constraint is the final duplicate-registration guard. The app uses SwingWorker for database work.
