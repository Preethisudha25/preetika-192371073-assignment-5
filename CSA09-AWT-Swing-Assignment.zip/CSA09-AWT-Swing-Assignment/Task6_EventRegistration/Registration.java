public class Registration {
    public final long id;
    public final String studentId, studentName, eventName, registeredAt;
    public Registration(long id, String studentId, String studentName, String eventName, String registeredAt) {
        this.id = id; this.studentId = studentId; this.studentName = studentName;
        this.eventName = eventName; this.registeredAt = registeredAt;
    }
}
