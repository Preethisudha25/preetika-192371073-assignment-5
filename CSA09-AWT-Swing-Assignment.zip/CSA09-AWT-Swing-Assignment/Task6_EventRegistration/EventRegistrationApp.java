import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.SQLException;
import java.util.*;

public class EventRegistrationApp extends JFrame {
    private final RegistrationService service = new RegistrationService();
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final JTextField studentId = new JTextField(14), studentName = new JTextField(14);
    private final JComboBox<EventChoice> registerEvent = new JComboBox<>();
    private final JComboBox<EventChoice> filterEvent = new JComboBox<>();
    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Student ID", "Student Name", "Event", "Registered At"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel registerStatus = new JLabel("Ready.");
    private final JLabel pageStatus = new JLabel("Page 1");
    private final JButton previous = new JButton("Previous"), next = new JButton("Next");
    private final int pageSize = 50;
    private int page = 0;
    private boolean busy = false;

    private static class EventChoice {
        final Integer id; final String name;
        EventChoice(Integer id, String name) { this.id=id; this.name=name; }
        @Override public String toString() { return name; }
    }

    public EventRegistrationApp() {
        super("Campus Event Registration");
        setJMenuBar(createMenu());
        content.add(createRegistrationPanel(), "register");
        content.add(createCommitteePanel(), "committee");
        add(content);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) {
                if (busy) {
                    int answer = JOptionPane.showConfirmDialog(EventRegistrationApp.this,
                            "An operation is in progress. Close anyway?", "Confirm exit", JOptionPane.YES_NO_OPTION);
                    if (answer != JOptionPane.YES_OPTION) return;
                }
                dispose();
            }
        });
        setSize(850, 520);
        setLocationRelativeTo(null);
        loadEvents();
    }

    private JMenuBar createMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu registration = new JMenu("Registration");
        JMenuItem newReg = new JMenuItem("New Registration");
        newReg.addActionListener(e -> cards.show(content, "register"));
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> dispatchEvent(new java.awt.event.WindowEvent(this, java.awt.event.WindowEvent.WINDOW_CLOSING)));
        registration.add(newReg); registration.add(exit);
        JMenu committee = new JMenu("Committee");
        JMenuItem view = new JMenuItem("View Registrations");
        view.addActionListener(e -> { cards.show(content, "committee"); loadPage(); });
        JMenuItem export = new JMenuItem("Export CSV");
        export.addActionListener(e -> exportCsv());
        committee.add(view); committee.add(export);
        bar.add(registration); bar.add(committee);
        return bar;
    }

    private JPanel createRegistrationPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8,8,8,8); g.anchor = GridBagConstraints.WEST;
        addRow(panel,g,0,"Student ID",studentId);
        addRow(panel,g,1,"Student Name",studentName);
        addRow(panel,g,2,"Event",registerEvent);
        JButton register = new JButton("Register");
        g.gridx=1; g.gridy=3; panel.add(register,g);
        g.gridx=0; g.gridy=4; g.gridwidth=2; panel.add(registerStatus,g);
        register.addActionListener(e -> registerStudent(register));
        return panel;
    }

    private void addRow(JPanel p, GridBagConstraints g, int y, String label, Component input) {
        g.gridwidth=1; g.gridx=0; g.gridy=y; p.add(new JLabel(label + ":"),g);
        g.gridx=1; p.add(input,g);
    }

    private JPanel createCommitteePanel() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Filter by event:")); top.add(filterEvent);
        JButton apply = new JButton("Apply Filter"), export = new JButton("Export CSV");
        top.add(apply); top.add(export);
        apply.addActionListener(e -> { page=0; loadPage(); });
        export.addActionListener(e -> exportCsv());
        p.add(top,BorderLayout.NORTH);
        p.add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel bottom = new JPanel(new FlowLayout());
        bottom.add(previous); bottom.add(pageStatus); bottom.add(next);
        previous.addActionListener(e -> { if(page>0){page--;loadPage();} });
        next.addActionListener(e -> { page++; loadPage(); });
        p.add(bottom,BorderLayout.SOUTH);
        return p;
    }

    private void loadEvents() {
        setBusy(true);
        new SwingWorker<Map<Integer,String>,Void>() {
            protected Map<Integer,String> doInBackground() throws Exception { return service.events(); }
            protected void done() {
                try {
                    Map<Integer,String> events=get();
                    for (Map.Entry<Integer,String> e:events.entrySet()) {
                        registerEvent.addItem(new EventChoice(e.getKey(),e.getValue()));
                        filterEvent.addItem(new EventChoice(e.getKey(),e.getValue()));
                    }
                    filterEvent.insertItemAt(new EventChoice(null,"All events"),0);
                    filterEvent.setSelectedIndex(0);
                    registerStatus.setText(events.isEmpty()?"No events found. Run schema.sql first.":"Ready.");
                } catch(Exception ex) { registerStatus.setText("Could not load events: "+rootMessage(ex)); }
                finally { setBusy(false); }
            }
        }.execute();
    }

    private void registerStudent(JButton button) {
        EventChoice selected=(EventChoice)registerEvent.getSelectedItem();
        Integer eventId=selected==null?null:selected.id;
        String id=studentId.getText(), name=studentName.getText();
        try {
            if(id.trim().isEmpty()||name.trim().isEmpty()||eventId==null)
                throw new IllegalArgumentException("Enter student ID and name, and choose an event.");
        } catch(IllegalArgumentException ex) { JOptionPane.showMessageDialog(this,ex.getMessage(),"Validation",JOptionPane.WARNING_MESSAGE); return; }
        setBusy(true); button.setEnabled(false); registerStatus.setText("Saving registration...");
        new SwingWorker<Void,Void>() {
            protected Void doInBackground() throws Exception { service.register(id,name,eventId); return null; }
            protected void done() {
                try {
                    get(); registerStatus.setText("Registration successful.");
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,"Registration completed.");
                    studentId.setText(""); studentName.setText("");
                } catch(Exception ex) {
                    String msg=rootMessage(ex);
                    if(msg.toLowerCase().contains("duplicate") || msg.contains("uq_student_event"))
                        msg="This student is already registered for this event.";
                    registerStatus.setText("Registration failed: "+msg);
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,msg,"Registration Error",JOptionPane.ERROR_MESSAGE);
                } finally { button.setEnabled(true); setBusy(false); }
            }
        }.execute();
    }

    private Integer selectedFilter() {
        EventChoice c=(EventChoice)filterEvent.getSelectedItem();
        return c==null?null:c.id;
    }

    private void loadPage() {
        setBusy(true); previous.setEnabled(false); next.setEnabled(false); pageStatus.setText("Loading...");
        Integer filter=selectedFilter();
        new SwingWorker<java.util.List<Registration>,Void>() {
            protected java.util.List<Registration> doInBackground() throws Exception { return service.page(filter,page,pageSize); }
            protected void done() {
                try {
                    java.util.List<Registration> rows=get();
                    model.setRowCount(0);
                    for(Registration r:rows) model.addRow(new Object[]{r.id,r.studentId,r.studentName,r.eventName,r.registeredAt});
                    pageStatus.setText("Page "+(page+1)+" ("+rows.size()+" rows)");
                    previous.setEnabled(page>0);
                    next.setEnabled(rows.size()==pageSize);
                } catch(Exception ex) {
                    pageStatus.setText("Load failed: "+rootMessage(ex));
                    if(page>0) page--;
                } finally { setBusy(false); }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser chooser=new JFileChooser();
        chooser.setSelectedFile(new File("registrations.csv"));
        if(chooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION) return;
        File file=chooser.getSelectedFile();
        Integer filter=selectedFilter();
        setBusy(true);
        new SwingWorker<java.util.List<Registration>,Void>() {
            protected java.util.List<Registration> doInBackground() throws Exception {
                java.util.List<Registration> all=new ArrayList<>();
                int p=0; java.util.List<Registration> batch;
                do { batch=service.page(filter,p++,500); all.addAll(batch); } while(batch.size()==500);
                return all;
            }
            protected void done() {
                try(BufferedWriter w=Files.newBufferedWriter(file.toPath(),StandardCharsets.UTF_8)) {
                    w.write("Registration ID,Student ID,Student Name,Event,Registered At\n");
                    for(Registration r:get()) w.write(csv(r.id)+","+csv(r.studentId)+","+csv(r.studentName)+","+csv(r.eventName)+","+csv(r.registeredAt)+"\n");
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,"CSV exported: "+file.getAbsolutePath());
                } catch(Exception ex) { JOptionPane.showMessageDialog(EventRegistrationApp.this,rootMessage(ex),"Export Error",JOptionPane.ERROR_MESSAGE); }
                finally { setBusy(false); }
            }
        }.execute();
    }

    private String csv(Object value) { return "\""+String.valueOf(value).replace("\"","\"\"")+"\""; }
    private String rootMessage(Throwable t) {
        Throwable x=t;
        while(x.getCause()!=null) x=x.getCause();
        return x.getMessage()==null?x.toString():x.getMessage();
    }
    private void setBusy(boolean value) { busy=value; }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventRegistrationApp().setVisible(true));
    }
}
