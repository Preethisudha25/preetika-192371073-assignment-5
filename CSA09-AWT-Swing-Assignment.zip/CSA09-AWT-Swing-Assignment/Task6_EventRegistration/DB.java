import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DB {
    private DB() {}
    public static Connection getConnection() throws SQLException {
        String url = System.getenv().getOrDefault("CAMPUS_DB_URL", "jdbc:mysql://localhost:3306/campus_events");
        String user = System.getenv().getOrDefault("CAMPUS_DB_USER", "root");
        String password = System.getenv().getOrDefault("CAMPUS_DB_PASSWORD", "CHANGE_ME");
        return DriverManager.getConnection(url, user, password);
    }
}
