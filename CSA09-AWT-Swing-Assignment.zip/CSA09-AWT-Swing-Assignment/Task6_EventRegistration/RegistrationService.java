import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class RegistrationService {
    private final RegistrationDAO dao = new RegistrationDAO();
    public Map<Integer, String> events() throws SQLException { return dao.getEvents(); }
    public void register(String id, String name, Integer eventId) throws SQLException {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("Student ID is required.");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Student name is required.");
        if (eventId == null) throw new IllegalArgumentException("Choose an event.");
        dao.insert(id.trim(), name.trim(), eventId);
    }
    public List<Registration> page(Integer eventId, int page, int pageSize) throws SQLException {
        if (page < 0 || pageSize < 1) throw new IllegalArgumentException("Invalid page.");
        return dao.findPage(eventId, pageSize, page * pageSize);
    }
}
