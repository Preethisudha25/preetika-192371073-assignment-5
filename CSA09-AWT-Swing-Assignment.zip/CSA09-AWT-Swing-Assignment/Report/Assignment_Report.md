# CSA09 – AWT and Swing Assignment
**Implementation:** Java AWT and Swing  
**Student Name:** ____________________  
**Register Number:** ____________________  
**GitHub Repository:** ____________________

---

# Task 1 – GUI Design Review (6 Marks)

## 1.1 Diagnosis

| Deficiency | What can go wrong / user experience |
|---|---|
| UI, validation, JDBC and payment logic are all in one listener | The window is tightly coupled to the database and is difficult to test or change independently. |
| `==` is used for String comparison | It compares object references, not text values; the Pay branch may not run as intended. Use `"Pay".equals(e.getActionCommand())` or separate listeners. |
| No validation for empty/invalid registration number or amount | Empty input or non-numeric/negative amount can cause exceptions or invalid records. |
| JDBC and `Thread.sleep(3000)` run on the AWT event-dispatch thread | The window freezes; repainting and other clicks are delayed for at least three seconds. |
| SQL is built by concatenating user input | SQL injection is possible; quotes in the registration number can also break the query. Use `PreparedStatement`. |
| No useful feedback or error handling | The user sees only console output and cannot tell whether payment succeeded or failed in the window. |
| Receipt button is not implemented | It falls into the `else` branch and clears the fields instead of showing a receipt. |
| No explicit connection/statement closing | Database resources may leak. Use try-with-resources. |
| No window-closing handler | The application may not dispose the frame cleanly or may leave resources running. |
| Checked exceptions are not handled | JDBC exceptions and interruption must be caught or declared; the user receives no controlled error message. |

## 1.2 Repaired class structure

- `FeeWindow` – collects input, starts background work and displays status.
- `FeeService` – validates values and performs the payment database operation.
- `FeeRepository` – JDBC persistence using a parameterized statement (production separation).
- A `SwingWorker`/background thread prevents database work from blocking the UI.

See `Task1_FeePayment/FeePaymentApp.java`. It uses AWT and a background worker; credentials are placeholders and should be configured locally.

## Event-handling pseudocode

```
ON Pay button:
    read registration number and amount from fields
    disable Pay button; show "Processing..."
    start background task:
        result = FeeService.pay(registrationNumber, amount)
    when task completes on UI thread:
        enable Pay button
        show success receipt or clear error message

ON Clear button:
    clear registration and amount fields
    clear status

ON Receipt button:
    if a successful payment exists:
        display receipt details
    else:
        display "No completed payment"

ON window close:
    ask for confirmation
    if confirmed: dispose window
```

## 1.3 Design defence (under 100 words)

The redesign separates presentation from business rules and database access. The service can be tested without opening a window, while the frame can be tested with a fake service. Validation and SQL are no longer duplicated inside event handlers. Parameterized SQL reduces injection risk, and try-with-resources closes database objects reliably. Background execution keeps the interface responsive. Each button has a clear responsibility, making future changes such as adding refunds or receipt formatting easier to locate and verify.

## Alternative: one listener per button

With one shared listener and an `if–else` chain, dispatch may perform up to `k` action-command comparisons, so worst-case dispatch is O(k) and the listener object count can be O(1). With a separate listener/action per button, dispatch is effectively O(1) after the event source selects its registered listener, but k listener/action objects require O(k) space. In practice, event-handler execution and database work dominate these tiny dispatch costs. Separate listeners improve cohesion and readability.

---

# Task 2 – Requirement to Event-Driven Design (8 Marks)

## 2.1 Event model

| Event source | Event object | Listener interface | Action |
|---|---|---|---|
| Patient ID text field (Enter) | `ActionEvent` | `ActionListener` | Optionally validate/lookup patient |
| Department combo box | `ItemEvent` / `ActionEvent` | `ItemListener` / `ActionListener` | Refresh doctor choices |
| Doctor combo box | `ActionEvent` | `ActionListener` | Update selected doctor state |
| Time-slot combo box | `ActionEvent` | `ActionListener` | Update selected slot |
| Book button | `ActionEvent` | `ActionListener` | Validate and book |
| Window close control | `WindowEvent` | `WindowListener` / `WindowAdapter` | Confirm close if booking is in progress |

## 2.2 Component containment tree

```
JFrame: AppointmentDeskFrame (BorderLayout)
├── JPanel: Header (FlowLayout)
│   └── JLabel: "Outpatient Appointment Desk"
├── JPanel: Form (GridLayout(5,2))
│   ├── JLabel + JTextField: Patient ID
│   ├── JLabel + JComboBox: Department
│   ├── JLabel + JComboBox: Doctor
│   ├── JLabel + JComboBox: Time slot
│   └── JButton: Book appointment
└── JPanel: Footer (BorderLayout)
    ├── JLabel: Status (CENTER)
    └── JButton: Close (EAST)
```

## 2.3 Handler pseudocode

```
ON department selection changes:
    selectedDepartment = departmentCombo.selectedItem
    doctorCombo.removeAllItems()
    for each doctor in doctorsByDepartment[selectedDepartment]:
        doctorCombo.addItem(doctor)
    if no doctors:
        disable doctorCombo
    else:
        enable doctorCombo
```

```
ON Book:
    set bookingInProgress = true
    validate patient ID is not blank
    validate department, doctor and time slot are selected
    if any validation fails:
        show a clear message
        set bookingInProgress = false
        return
    disable Book button
    run booking service in background
    when complete:
        set bookingInProgress = false
        enable Book button
        show confirmation or error
```

## 2.4 Event sequence and applet comparison

1. `main` schedules GUI creation on the Swing event-dispatch thread.
2. Constructor creates components, registers listeners and packs the frame.
3. `setVisible(true)` displays the frame.
4. User actions generate events; registered listener methods run on the event-dispatch thread.
5. A booking starts background work; completion is posted back to the UI thread.
6. Close control generates `WINDOW_CLOSING`; `windowClosing` asks for confirmation.
7. If confirmed, `dispose()` releases the native window resources; `windowClosed` may then be delivered.

Applet comparison: `init()` initializes once, `start()` begins/resumes activity, `paint()` renders, `stop()` pauses activity, and `destroy()` releases resources. A desktop JFrame instead uses constructors, visibility, event callbacks, `paintComponent`/painting, and `dispose()`; it has no applet lifecycle.

## Alternative: doctor data in a Map vs database query on each change

Preloading `Map<String,List<Doctor>>` costs O(d+m) storage for d departments and m total doctors, then department lookup is expected O(1) plus O(mᵢ) to populate the selected department's list. Querying the database each time uses little persistent doctor-list memory (roughly O(mᵢ) for the current result) but adds network/database latency and query cost O(log m + mᵢ) with a suitable index, or worse without one. Preloading is faster for repeated changes but may become stale and uses more memory.

---

# Task 3 – From Sketch to Layout (9 Marks)

## 3.1 Layout choices

- Main frame: `BorderLayout`. It gives distinct top, centre and bottom regions.
- Search row: `FlowLayout(LEFT)`. Controls retain preferred sizes and remain in a compact row.
- Results region: `BorderLayout` containing a `JScrollPane` around a `JTable`. The centre receives remaining space and grows when resized.
- Bottom navigation row: `FlowLayout(CENTER)`. Buttons retain preferred sizes.
- Status: a `JLabel` in the frame's `SOUTH` region, placed in a small footer panel.

`GridLayout` is unsuitable for the whole screen because it forces equal-sized cells. `CardLayout` is useful for switching whole screens, not for this single simultaneous layout.

## 3.2 Nested structure

```
JFrame LibrarySearchFrame [BorderLayout]
├── JPanel top [BorderLayout.NORTH]
│   └── JPanel searchRow [FlowLayout.LEFT]
│       ├── JLabel "Search"
│       ├── JTextField
│       ├── JComboBox category
│       └── JButton Search
├── JScrollPane [BorderLayout.CENTER]
│   └── JTable results
└── JPanel bottom [BorderLayout.SOUTH]
    ├── JPanel navigation [FlowLayout.CENTER]
    │   ├── JButton Prev
    │   ├── JButton Next
    │   └── JButton Reserve
    └── JLabel status
```

## 3.3 Implementation

See `Task3_LibrarySearch/LibrarySearchScreen.java`.

## 3.4 Resizing test plan

| Test | Window size | Expected result |
|---|---:|---|
| T3-R1 | 500 × 350 | Results area becomes compact and may show scrollbars; top and bottom controls keep preferred sizes. |
| T3-R2 | 800 × 550 | Results area expands to use available centre space. |
| T3-R3 | 1200 × 800 | Results area grows substantially; search and navigation rows remain compact. |

Capture actual screenshots at these three sizes and place them in `evidence/`. Do not claim a screenshot exists until you have run the program and captured it.

## Alternative: GridBagLayout or absolute positioning

`GridBagLayout` can produce a similar responsive design with weights and fill constraints, but its constraints are more complex; layout calculation is generally O(c) in the number of components. Absolute positioning has low setup/layout overhead but does not adapt to resizing, font scaling or platform differences; every component needs manual bounds. Nested BorderLayout/FlowLayout uses several small panel objects (O(c) containers/components overall) and simple layout passes, also approximately O(c), but is easier to maintain. The extra panel objects are a small O(p) space cost.

---

# Task 4 – Event-Handling Forensics (7 Marks)

## 4.1 Defect

The callback is written as `mouseclicked`, but the required method name and capitalization are `mouseClicked(MouseEvent e)`. Java is case-sensitive, so the method does not override the adapter method and is never called. The label is never updated because the original code contains no `status.setText(...)` call.

## 4.2 Failing interaction

Click several times to draw dots, then minimize the window and restore it. The dots disappear because `getGraphics()` draws directly to the current screen surface. The operating system may repaint that surface after restoration, and the application has not retained the points to redraw them.

## 4.3 Repair

See `Task4_DrawPad/DrawPad.java`. It stores each click as a `Point`, updates the label, calls `repaint()`, and draws all points in `paint(Graphics)`.

## 4.4 Prevention

With `@Override`, writing `mouseclicked` produces a compile-time error because no superclass method with that exact signature exists. The annotation makes the compiler verify the intended override.

### Required compile-error experiment

Temporarily change `mouseClicked` to `mouseclicked` and add `@Override` above it. Compile the file and capture the compiler diagnostic. Then restore the correct spelling and run the program. The exact diagnostic wording depends on the JDK/compiler.

### Complexity alternative: BufferedImage

With a list of n points, every repaint redraws n circles: O(n) time per repaint and O(n) point storage. With an off-screen `BufferedImage`, each click paints into the image and each repaint copies the image to the screen: O(width × height) image-copy work (often optimized by the graphics pipeline), while drawing each new dot is O(1). The image uses O(width × height) pixels of memory instead of O(n) point records. The point list is better when editing/undoing individual points is needed.

---

# Task 5 – Same Screen, Different Event-Handling Styles (7 Marks)

## 5.1 Four implementations

Four independent source files are supplied:
- `ConverterFrameListener.java` – frame implements `ActionListener`.
- `ConverterNamedInner.java` – named inner listener.
- `ConverterAnonymous.java` – anonymous listener.
- `ConverterLambda.java` – lambda version, with one shared `ActionListener` registered for the Convert button and Enter key.

Each uses a `WindowAdapter` to handle window closing. See each source file.

## 5.2 Requirement change: Enter and dialog

The supplied versions register the same conversion action with both the button and the text field's Enter event, and display the result/error in a dialog. For the frame-listener version, the handler must distinguish the event source if different actions are required; for inner/anonymous/lambda versions, register the same handler with the second source. The shared conversion method keeps business logic unchanged.

## 5.3 Comparison

| Style | Readability | Access to fields | Reuse | Change effort |
|---|---|---|---|---|
| Frame implements listener | Simple for tiny windows; frame can become crowded | Direct | Low; frame itself is handler | Add source registration and source checks |
| Named inner class | Clear separation and descriptive name | Direct access to enclosing fields | Good; can register same instance repeatedly | Small: register it with the new source |
| Anonymous inner class | Compact for one-off handler | Direct | Low unless stored in a field | Duplicate/register another anonymous object or store it |
| Lambda | Concise for a small functional callback | Captures enclosing fields | Good when stored in a variable | Register same lambda with the new source |

For a large application, use a separate controller/action class or a shared Swing `Action`. It separates responsibilities, supports reuse from buttons, menus and keyboard shortcuts, and is easier to unit test.

## Alternative: method reference or shared Action

`this::convert` is a concise method reference if the method signature matches the listener callback. A single `Action` object can be registered with a button and menu item and bound to a keyboard shortcut through the Swing input/action maps. This avoids creating a new handler for every trigger; one shared object uses O(1) handler space, while separate listener objects can use O(k) space for k triggers. Adding a trigger to a shared Action is usually one registration/binding; duplicated handlers require repeated code and can drift.

---

# Task 6 – Design Challenge: Campus Event Registration (13 Marks)

## Stage 1 – Users, screens, data and rules

**Users**
- Student: submits a registration.
- Committee member: views, filters and exports registrations.

**Screens**
- Registration screen: student ID, student name, event selector, Register button and status.
- Committee screen: filter selector, paginated JTable, Previous/Next and Export CSV.
- Dialogs: validation errors, duplicate registration warning and success confirmation.

**Data**
- Student: student ID and name.
- Event: event ID, event name and date.
- Registration: registration ID, student ID, event ID and registration timestamp.

**Testable requirements**
1. A blank student ID or name is rejected with a visible validation message.
2. An event must be selected before registration.
3. The database unique constraint on `(student_id,event_id)` prevents duplicate registration even if two requests arrive concurrently.
4. Database calls do not execute on the Swing event-dispatch thread.
5. The committee can filter by event and view one page at a time.
6. Export writes the currently filtered registration list to CSV.
7. A database failure is shown as a clear error and does not freeze the interface.

## Stage 2 – Screen and event flow

```
JFrame EventRegistrationApp [JMenuBar]
├── Menu: Registration
│   ├── New Registration
│   └── Exit
├── Menu: Committee
│   ├── View Registrations
│   └── Export CSV
└── CardLayout content
    ├── RegistrationPanel
    │   ├── Student ID field
    │   ├── Student Name field
    │   ├── Event combo
    │   └── Register button + status
    └── CommitteePanel
        ├── Event filter combo
        ├── JTable inside JScrollPane
        ├── Previous / Next
        └── Export button
```

Flow: Start → Registration or Committee view. Registration → validate → duplicate-safe insert → success/error dialog. Committee → choose event filter → asynchronous paged query → table update → next/previous page or export CSV. Exit → confirm if an operation is active → close.

## Stage 3 – Critical decisions

- UI-level validation gives immediate feedback; service-level validation enforces rules even if another UI is added.
- Duplicate prevention is enforced by a database `UNIQUE(student_id,event_id)` constraint, not only by a prior SELECT. The insert catches duplicate-key errors.
- JDBC code belongs in the DAO/repository layer.
- `SwingWorker` runs database work in `doInBackground()` and updates controls in `done()` on the EDT.
- Prepared statements prevent SQL injection.
- Use try-with-resources for connections, statements and result sets.

## Stage 4 – Class design and pseudocode

```
EventRegistrationApp (JFrame)
  ├── RegistrationPanel
  ├── CommitteePanel
  └── EventRegistrationService
        └── RegistrationDAO (JDBC)
              └── MySQL database

RegistrationPanel -> EventRegistrationService.register(...)
CommitteePanel -> EventRegistrationService.findPage(...)
EventRegistrationService -> RegistrationDAO
```

**Register action**
```
read studentId, studentName, eventId
if any required field is blank:
    show validation error; return
disable Register button
SwingWorker:
    call service.register(studentId, studentName, eventId)
done:
    enable Register button
    show success or duplicate/database error
```

**Filter action**
```
read selected event filter
set page = 0
disable filter/navigation while loading
SwingWorker:
    rows = DAO.findPage(filter, page, pageSize)
done:
    replace table model rows
    update page label and navigation enabled state
    show error if query failed
```

## Stage 5 – Implementation and test cases

See `Task6_EventRegistration/`. The application uses Swing components, a service layer, JDBC DAO, SQL pagination with `LIMIT`/`OFFSET`, a unique database constraint, background workers and CSV export.

| Test ID | Input/action | Expected result |
|---|---|---|
| T6-01 | Valid student details + event | One row inserted; success shown |
| T6-02 | Empty student ID | Validation message; no insert |
| T6-03 | Submit same student/event again | Duplicate warning; only one row exists |
| T6-04 | Select event filter | Only matching event rows displayed |
| T6-05 | Next page | Next page loaded without freezing UI |
| T6-06 | Export | CSV file contains filtered registrations |

### Alternative: load all 100,000 rows vs paginated loading

Loading all 100,000 rows has O(N) query/transfer and table-model construction time, and O(N) client memory; it can cause long pauses, high memory use and an unresponsive UI if performed on the EDT. With page size P, each page transfers and stores O(P) rows, and the initial page is usually faster. Navigating all pages still costs O(N) total over time, but peak client memory is O(P) and background `SwingWorker` keeps the EDT responsive. SQL `LIMIT/OFFSET` can become slower at large offsets; keyset pagination is a better scalable alternative. Database indexes on event ID and registration ID improve filtering and ordering.

---

# Submission evidence checklist

- [ ] Replace student details and add GitHub URL.
- [ ] Run and test every program.
- [ ] Capture genuine screenshots for every specified interaction and label them with test IDs.
- [ ] Capture the deliberate compile-error experiment for Task 4.
- [ ] Add MySQL Connector/J locally and configure DB credentials securely.
- [ ] Run the SQL script and test valid, invalid and duplicate registrations.
- [ ] Push the complete project to GitHub and verify the repository link.
