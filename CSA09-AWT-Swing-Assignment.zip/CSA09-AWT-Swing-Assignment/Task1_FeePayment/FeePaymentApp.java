import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.concurrent.*;

public class FeePaymentApp extends Frame {
    private final TextField regNo = new TextField(18);
    private final TextField amount = new TextField(18);
    private final Label status = new Label("Enter details and select Pay.");
    private final Button pay = new Button("Pay");
    private final Button clear = new Button("Clear");
    private final Button receipt = new Button("Receipt");
    private final FeeService service = new FeeService();
    private volatile String lastReceipt = "";

    public FeePaymentApp() {
        super("Student Fee Payment");
        setLayout(new BorderLayout(8, 8));
        Panel fields = new Panel(new GridLayout(2, 2, 6, 6));
        fields.add(new Label("Registration number:"));
        fields.add(regNo);
        fields.add(new Label("Amount:"));
        fields.add(amount);
        Panel actions = new Panel(new FlowLayout());
        actions.add(pay); actions.add(clear); actions.add(receipt);
        add(fields, BorderLayout.NORTH);
        add(actions, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);

        pay.addActionListener(e -> payFee());
        clear.addActionListener(e -> {
            regNo.setText(""); amount.setText(""); status.setText("Fields cleared.");
        });
        receipt.addActionListener(e -> {
            status.setText(lastReceipt.isEmpty() ? "No completed payment." : lastReceipt);
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (EventQueue.isDispatchThread()) dispose();
            }
        });
        setSize(430, 170);
    }

    private void payFee() {
        final String id = regNo.getText().trim();
        final String rawAmount = amount.getText().trim();
        final double value;
        try {
            if (id.isEmpty()) throw new IllegalArgumentException("Registration number is required.");
            value = Double.parseDouble(rawAmount);
            if (!Double.isFinite(value) || value <= 0) throw new IllegalArgumentException("Amount must be greater than zero.");
        } catch (RuntimeException ex) {
            status.setText("Invalid input: " + ex.getMessage());
            return;
        }
        pay.setEnabled(false);
        status.setText("Processing payment...");
        new SwingLikeWorker(id, value).execute();
    }

    private final class SwingLikeWorker {
        private final String id; private final double value;
        SwingLikeWorker(String id, double value) { this.id = id; this.value = value; }
        void execute() {
            Thread worker = new Thread(() -> {
                try {
                    String receiptText = service.pay(id, value);
                    EventQueue.invokeLater(() -> {
                        lastReceipt = receiptText; status.setText(receiptText); pay.setEnabled(true);
                    });
                } catch (Exception ex) {
                    EventQueue.invokeLater(() -> { status.setText("Payment failed: " + ex.getMessage()); pay.setEnabled(true); });
                }
            }, "fee-payment-worker");
            worker.setDaemon(true); worker.start();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new FeePaymentApp().setVisible(true));
    }
}

class FeeService {
    // Configure these locally; never publish real credentials.
    private static final String URL = "jdbc:mysql://localhost:3306/college";
    private static final String USER = "root";
    private static final String PWD = "CHANGE_ME";

    String pay(String regNo, double amount) throws SQLException {
        if (regNo == null || regNo.trim().isEmpty() || amount <= 0 || !Double.isFinite(amount))
            throw new IllegalArgumentException("Invalid payment details.");
        String sql = "INSERT INTO fees(reg_no, amount) VALUES (?, ?)";
        try (Connection c = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, regNo.trim());
            ps.setDouble(2, amount);
            ps.executeUpdate();
        }
        return String.format("Payment recorded for %s: %.2f", regNo, amount);
    }
}
